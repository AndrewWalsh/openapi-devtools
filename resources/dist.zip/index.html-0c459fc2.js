import "./modulepreload-polyfill-7faf532e.js";
chrome.devtools.panels.create(
  "OpenAPI",
  "icon16.png",
  "/src/panel.html"
);
//# sourceMappingURL=index.html-0c459fc2.js.map
